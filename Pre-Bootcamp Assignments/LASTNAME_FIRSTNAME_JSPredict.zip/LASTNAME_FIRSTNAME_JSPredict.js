function myBirthYearFunc() {
    console.log("I was born in " + 1980);  
}

myBirthYearFunc()

//Predict 1 will give us I was born in 1980 if you call the function myBirthYearFunc().


/*function myBirthYearFunc(birthYearInput){
  var birthYearInput = 1980;
  console.log("I was born in " + birthYearInput);
}

myBirthYearFunc()*/

/*Predict 2 will give us I was born in undefined because the parameter birthYearInput that is called 
doesn't have a value. It is currently empty.You simply make var birthYearInput = 1980; and call the 
function.*/


/*function add(num1, num2){
  var num1 = 10;
  var num2 = 20;
  var sum = num1 + num2;
  console.log("Summing Numbers!");
  console.log("num1 is: " + num1);
  console.log("num2 is: " + num2);
  console.log(sum);  
}

add()*/

/*Predict 3 would give us 30 for the sum if var num1 = 10 and var num2 = 20 because the sum is supposed 
to be num1 + num2. Other logs would give us Summing Numbers!, num1 is: 10, num2 is: 20.*/
